import ij.*;
import ij.plugin.*;
import ij.process.*;
import ij.gui.*;

/*
IsoPhotContour_ by Gabriel Landini G.Landini at bham. ac. uk
This plugin creates a number of contour level curves equally separated in the
greyscale space
20 Oct 2003 Released 1.0
30 Nov 2003 version 1.1, changed equality test for strings.
3 Feb 2007 version 1.2 supports stacks, added 'none'


*/
public class IsoPhotContour_ implements PlugIn {

	public void run(String arg) {

		ImagePlus img = WindowManager.getCurrentImage();
		if (img==null){
			IJ.error("Error","No image!.\nPlease open a binary (8-bit) image.");
			return;
		}

		if (img.getType()!=ImagePlus.GRAY8){
			IJ.error("Error","8 bit images only!");
			return;
		}
	
		ImageProcessor ip = img.getProcessor();
		int stk = img.getStackSize();
		int i=8,x,y,v,j,bck;
		int xe=ip.getWidth(), ye=ip.getHeight();
		int [][] p = new  int[xe][ye];
		boolean done=false, to8bit=false, contr=false, bb=false;


			GenericDialog gd = new GenericDialog("IsoPhotContour v1.2", IJ.getInstance());
			gd.addMessage("Input the number of levels");
			gd.addNumericField ("Levels",  i, 0);
			gd.addCheckbox ("Contours only",contr);
			gd.addCheckbox ("Black background",bb);
			gd.addCheckbox ("Convert to 8bit colour", false);

			gd.showDialog();
			if (gd.wasCanceled()){
				done=true;
				return;
			}

			i=(int) gd.getNextNumber();
			j= 255/i;

			contr= gd.getNextBoolean();
			bb= gd.getNextBoolean();
			to8bit= gd.getNextBoolean();

			if(bb==true)
				bck=0;
			else
				bck=((255 & 0xff)<<16)+((255 & 0xff)<<8)+(255 & 0xff);

		IJ.run("Duplicate...", "title=IsoPhot duplicate");
		IJ.run("RGB Color");
		//IJ.selectWindow("IsoPhot");
		ImagePlus img2 = WindowManager.getCurrentImage();
		ImageProcessor ip2 = img2.getProcessor();


		if(bb==true)
			bck=0;
		else
			bck=((255 & 0xff)<<16)+((255 & 0xff)<<8)+(255 & 0xff);

		for (i=1; i<=stk; i++) {

			img.setSlice(i);

			for (y=0;y<ye; y++) {
				for (x=0; x<xe; x++) {
					p[x][y]=ip.getPixel(x,y);
				}
			}

			img2.setSlice(i);

			if (contr==true){
				for (y=0;y<ye; y++) {
					for (x=0; x<xe; x++)
						ip2.putPixel(x,y,bck);
				}
			}
			img.updateAndDraw();

			for (y=1;y<ye-1;y++) {
				for (x=1;x<xe-1;x++) {
					for (v=0;v<256;v+=j)
						if(p[x][y] <= v && (p[x-1][y-1] > v || p[x][y-1] > v || p[x+1][y-1] > v
						|| p[x-1][y]> v || p[x+1][y] > v || p[x-1][y+1]>v || p[x][y+1]>v || p[x+1][y+1]> v))
						ip2.putPixel(x,y,((255-v & 0xff)<<16)+((v&0xff)<<8));
						//ip2.putPixel(x,y,((255 & 0xff)<<16)+((0&0xff)<<8)+(0&0xff));
				}
			}
			// top, bottom, left & right borders
			y=0;
			for (x=1;x<xe-1;x++) {
				for (v=0;v<256;v+=j)
					if(p[x][y] <= v && (p[x-1][y]> v || p[x+1][y] > v || p[x-1][y+1]>v || p[x][y+1]>v || p[x+1][y+1]> v))
					ip2.putPixel(x,y,((255-v & 0xff)<<16)+((v&0xff)<<8));
			}
			y=ye-1;
			for (x=1;x<xe-1;x++) {
				for (v=0;v<256;v+=j)
					if(p[x][y] <= v && (p[x-1][y-1] > v || p[x][y-1] > v || p[x+1][y-1] > v || p[x-1][y]> v || p[x+1][y] > v))
						ip2.putPixel(x,y,((255-v & 0xff)<<16)+((v&0xff)<<8));
			}
			x=0;
			for (y=1;y<ye-1;y++) {
				for (v=0;v<256;v+=j)
					if(p[x][y] <= v && (p[x][y-1] > v || p[x+1][y-1] > v || p[x+1][y] > v || p[x][y+1]>v || p[x+1][y+1]> v))
						ip2.putPixel(x,y,((255-v & 0xff)<<16)+((v&0xff)<<8));
			}
			x=xe-1;
			for (y=1;y<ye-1;y++) {
				for (v=0;v<256;v+=j)
					if(p[x][y] <= v && (p[x-1][y-1] > v || p[x][y-1] > v || p[x-1][y]> v || p[x-1][y+1]>v || p[x][y+1]>v))
					ip2.putPixel(x,y,((255-v & 0xff)<<16)+((v&0xff)<<8));
			}
			img2.updateAndDraw();
		}

		if (to8bit==true)
			IJ.run("8-bit Color", "number=256");

	}
}
